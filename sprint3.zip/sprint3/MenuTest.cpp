/*

Zackery Gualandi 10/5/2016

*/


#include <iostream>
#include <string>
#include <vector>
#include "Menu.h"

using namespace std;

int main()
{
	Menu test_menu;

	test_menu.openMainMenu();

	cin.get();
	return 0;
}